/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package crud;





/**
 *
 * @author Hugo53690506
 */
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
public class CRUD {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
           
         
           
            
            try {
            // Define o Look and Feel para Quaqua
            UIManager.setLookAndFeel(new SmartLookAndFeel());
           
         
 LoginDados2 ld = new LoginDados2();
            ld.setVisible(true);
       
           
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
       
    }
     
    
}
