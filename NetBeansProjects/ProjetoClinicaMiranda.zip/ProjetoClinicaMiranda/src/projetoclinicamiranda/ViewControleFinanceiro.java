/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package projetoclinicamiranda;

import com.mysql.cj.xdevapi.Result;
import com.sun.source.tree.BreakTree;
import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDesktopPane;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Hugo53690506
 */
public class ViewControleFinanceiro extends javax.swing.JInternalFrame {
    int valor_entrada;
    int valor_saida ;
    int valor_total ;
    int valor_receita;
     String valores2;
    String situacao ;
    private JDesktopPane painel;
    /**
     * Creates new form ViewControleFinanceiro
     */
    public ViewControleFinanceiro(JDesktopPane painel) {
        initComponents();
        atualizarTelaFinanceiro();
        codigo.setEnabled(false);
        this.painel = painel;
        atualizaReceita();
        atualizaDespesa();
        atualizaTotal();
        try {
            setMaximum(true);
        } catch (PropertyVetoException ex) {
            Logger.getLogger(ViewControleFinanceiro.class.getName()).log(Level.SEVERE, null, ex);
        }
        
      
    }
    public void atualizarTelaFinanceiro(){
            try {
            Connection connection = ProjetoClinica.conexaoBanco();
            String sql = "SELECT * FROM entrada_saida";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();
            DefaultTableModel tabelaAtualizarFinanceiro = (DefaultTableModel) tabelaControleFinanceiro.getModel();
            tabelaAtualizarFinanceiro.setNumRows(0);
            
            while(resultSet.next()){
            
                
                Object [] dadosFinancas = {resultSet.getString("id_entrada_saida"),resultSet.getString("nome_receita"),resultSet.getString("recebimento"),resultSet.getString("categoria"),resultSet.getString("data_entrada_valor"),resultSet.getString("descricao"),resultSet.getString("receita_despesa")};
                tabelaAtualizarFinanceiro.addRow(dadosFinancas);
                
                
            }
            resultSet.close();
            statement.close();
            connection.close();
            
            
        } catch (SQLException ex) {
            Logger.getLogger(ViewAgendamento.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    }
    public void atualizaTotal(){
        try {
            Connection connection = ProjetoClinica.conexaoBanco();
            String sql = "SELECT (SELECt SUM(recebimento) FROM entrada_saida WHERE receita_despesa = 'Receita')-(SELECt SUM(recebimento) FROM entrada_saida WHERE receita_despesa = 'Despesa') AS saldo_final;";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();
            while(resultSet.next()){
          saldo_atual.setText(resultSet.getString("saldo_final"));
            }
            resultSet.close();
            statement.close();
            connection.close();
            
            
        } catch (SQLException ex) {
            Logger.getLogger(ViewAgendamento.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void atualizaReceita(){
        try {
            Connection connection = ProjetoClinica.conexaoBanco();
            String sql = "SELECT SUM(recebimento)AS receita FROM entrada_saida WHERE receita_despesa = 'Receita';";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();
            while(resultSet.next()){
         lbEntrada.setText(resultSet.getString("receita"));
            }
            resultSet.close();
            statement.close();
            connection.close();
            
            
        } catch (SQLException ex) {
            Logger.getLogger(ViewAgendamento.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
        public void atualizaDespesa(){
        try {
            Connection connection = ProjetoClinica.conexaoBanco();
            String sql = "SELECT SUM(recebimento)AS despesa FROM entrada_saida WHERE receita_despesa = 'Despesa';";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();
            while(resultSet.next()){
         lbSaida.setText(resultSet.getString("despesa"));
            }
            resultSet.close();
            statement.close();
            connection.close();
            
            
        } catch (SQLException ex) {
            Logger.getLogger(ViewAgendamento.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
   

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jComboBox1 = new javax.swing.JComboBox<>();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        GroupEntradaSaida = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        lbEntrada = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        lbSaida = new javax.swing.JLabel();
        lbTotal = new javax.swing.JPanel();
        saldo_atual = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        nome = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        categoria = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        dataValor = new com.toedter.calendar.JDateChooser();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        descricao = new javax.swing.JTextArea();
        jLabel13 = new javax.swing.JLabel();
        valor = new javax.swing.JTextField();
        rdButtonEntrada = new javax.swing.JRadioButton();
        rdButtonSaida = new javax.swing.JRadioButton();
        buttonAdicionar = new javax.swing.JButton();
        codigo = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tabelaControleFinanceiro = new javax.swing.JTable();
        buttonAlterarControle = new javax.swing.JButton();
        buttonExcluirControle = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();

        jLabel4.setText("Nome :");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel7.setText("Dados");

        jLabel5.setText("Categoria :");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel6.setText("Data :");

        jLabel8.setText("Descrição :");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        setClosable(true);
        setMaximizable(true);
        setResizable(true);
        setMaximumSize(new java.awt.Dimension(2147, 2147483647));
        setPreferredSize(new java.awt.Dimension(1364, 654));

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jPanel2.setBackground(new java.awt.Color(204, 255, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lbEntrada.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        lbEntrada.setText("0");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(91, Short.MAX_VALUE)
                .addComponent(lbEntrada)
                .addGap(90, 90, 90))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(38, Short.MAX_VALUE)
                .addComponent(lbEntrada)
                .addGap(29, 29, 29))
        );

        jPanel4.setBackground(new java.awt.Color(255, 102, 102));
        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lbSaida.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        lbSaida.setText("0");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(95, 95, 95)
                .addComponent(lbSaida)
                .addContainerGap(97, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(35, Short.MAX_VALUE)
                .addComponent(lbSaida)
                .addGap(32, 32, 32))
        );

        lbTotal.setBackground(new java.awt.Color(255, 255, 255));
        lbTotal.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        saldo_atual.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        saldo_atual.setText("0");

        javax.swing.GroupLayout lbTotalLayout = new javax.swing.GroupLayout(lbTotal);
        lbTotal.setLayout(lbTotalLayout);
        lbTotalLayout.setHorizontalGroup(
            lbTotalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lbTotalLayout.createSequentialGroup()
                .addGap(85, 85, 85)
                .addComponent(saldo_atual)
                .addContainerGap(97, Short.MAX_VALUE))
        );
        lbTotalLayout.setVerticalGroup(
            lbTotalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lbTotalLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(saldo_atual)
                .addContainerGap(36, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(105, 105, 105)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(144, 144, 144)
                .addComponent(lbTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(35, Short.MAX_VALUE))
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel9.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel9.setText("Nome :");

        jLabel10.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel10.setText("Categoria :");

        categoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECIONE A CATEGORIA", "Aluguel", "Salário", "Conta de Luz", "Conta de Água", "Procedimentos Especiais", "Internet", "Produtos internos", "Materias descartáveis", "Marketing", "Impostos", "Outro" }));

        jLabel11.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel11.setText("Data :");

        jLabel12.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel12.setText("Descrição :");

        descricao.setColumns(20);
        descricao.setRows(5);
        jScrollPane3.setViewportView(descricao);

        jLabel13.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel13.setText("Valor :");

        GroupEntradaSaida.add(rdButtonEntrada);
        rdButtonEntrada.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        rdButtonEntrada.setText("Entrada");
        rdButtonEntrada.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rdButtonEntradaItemStateChanged(evt);
            }
        });
        rdButtonEntrada.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rdButtonEntradaMouseClicked(evt);
            }
        });
        rdButtonEntrada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdButtonEntradaActionPerformed(evt);
            }
        });

        GroupEntradaSaida.add(rdButtonSaida);
        rdButtonSaida.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        rdButtonSaida.setText("Saída");
        rdButtonSaida.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rdButtonSaidaItemStateChanged(evt);
            }
        });

        buttonAdicionar.setBackground(new java.awt.Color(255, 204, 204));
        buttonAdicionar.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        buttonAdicionar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/add_32dp_434343_FILL0_wght400_GRAD0_opsz40.png"))); // NOI18N
        buttonAdicionar.setText("Adicionar");
        buttonAdicionar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                buttonAdicionarMouseClicked(evt);
            }
        });
        buttonAdicionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonAdicionarActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel15.setText("Código :");

        tabelaControleFinanceiro.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nome ", "Valor", "Categoria", "Data", "Descrição", "Receita/Despesa"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabelaControleFinanceiro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelaControleFinanceiroMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tabelaControleFinanceiro);

        buttonAlterarControle.setBackground(new java.awt.Color(255, 204, 204));
        buttonAlterarControle.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        buttonAlterarControle.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/editImg.png"))); // NOI18N
        buttonAlterarControle.setText("Alterar");
        buttonAlterarControle.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                buttonAlterarControleMouseClicked(evt);
            }
        });
        buttonAlterarControle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonAlterarControleActionPerformed(evt);
            }
        });

        buttonExcluirControle.setBackground(new java.awt.Color(255, 204, 204));
        buttonExcluirControle.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        buttonExcluirControle.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/iconDelete.png"))); // NOI18N
        buttonExcluirControle.setText("Excluir");
        buttonExcluirControle.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                buttonExcluirControleMouseClicked(evt);
            }
        });
        buttonExcluirControle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonExcluirControleActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(nome, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel13)
                        .addGap(8, 8, 8))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addComponent(jLabel15))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(codigo, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(rdButtonEntrada)
                        .addGap(28, 28, 28)
                        .addComponent(rdButtonSaida))
                    .addComponent(valor, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(categoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jLabel11)
                        .addGap(18, 18, 18)
                        .addComponent(dataValor, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(buttonAdicionar)
                        .addGap(29, 29, 29)
                        .addComponent(buttonAlterarControle, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(buttonExcluirControle, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(199, 199, 199))
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(87, 87, 87)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 998, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dataValor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel9)
                        .addComponent(nome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel10)
                        .addComponent(categoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel13)
                        .addComponent(valor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel11)))
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(rdButtonEntrada)
                            .addComponent(rdButtonSaida)
                            .addComponent(buttonAdicionar, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(buttonAlterarControle, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(buttonExcluirControle, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jLabel12)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(codigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 281, Short.MAX_VALUE)
                .addGap(15, 15, 15))
        );

        jPanel5.setBackground(new java.awt.Color(255, 204, 204));

        jLabel14.setFont(new java.awt.Font("Trebuchet MS", 1, 36)); // NOI18N
        jLabel14.setText("Controle Financeiro");

        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addGap(59, 59, 59))
                    .addComponent(jSeparator2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 454, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(345, 345, 345))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(184, 184, 184)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 1142, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(26, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void rdButtonEntradaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdButtonEntradaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdButtonEntradaActionPerformed

    private void buttonAdicionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonAdicionarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_buttonAdicionarActionPerformed

    private void buttonAlterarControleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonAlterarControleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_buttonAlterarControleActionPerformed

    private void buttonExcluirControleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonExcluirControleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_buttonExcluirControleActionPerformed

    private void buttonAdicionarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonAdicionarMouseClicked
      
        if(situacao.equals("Receita")){
         try {
            Connection connection = ProjetoClinica.conexaoBanco();
            
            String sql = "SELECT saldo_lucro FROM entrada_saida ORDER BY id_entrada_saida DESC LIMIT 1";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();
            while(rs.next()){
                valores2 = rs.getString("saldo_lucro");
            }
            sql = "INSERT INTO entrada_saida(data_entrada_valor,recebimento,descricao,categoria,nome_receita,receita_despesa,saldo_lucro)"
            +"VALUES(?,?,?,?,?,?,recebimento + ?);";
             statement = connection.prepareStatement(sql);
             
            SimpleDateFormat dataFormat = new SimpleDateFormat("yyyy-MM-dd");
            String bancoDados  = dataFormat.format(dataValor.getDate());
            
            statement.setString(1, bancoDados);
            statement.setString(2,valor.getText());
            statement.setString(3,descricao.getText());
            statement.setString(4,categoria.getSelectedItem().toString());
            statement.setString(5,nome.getText());
            statement.setString(6,situacao);
            statement.setString(7, valores2);
           
            statement.execute();
            connection.close();
            statement.close();
            rs.close();
           
            

            JOptionPane.showMessageDialog(null,"Adicionado");
            atualizarTelaFinanceiro();
            atualizaReceita();
            atualizaDespesa();
            atualizaTotal();

        } catch (SQLException ex) {
            Logger.getLogger(ViewControleFinanceiro.class.getName()).log(Level.SEVERE, null, ex);
        }
            
          
        }else if(situacao.equals("Despesa")){
        
            try {
            Connection connection = ProjetoClinica.conexaoBanco();
            String sql = "SELECT saldo_lucro FROM entrada_saida ORDER BY id_entrada_saida DESC LIMIT 1";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();
            while(rs.next()){
                valores2 = rs.getString("saldo_lucro");
            }
             connection = ProjetoClinica.conexaoBanco();
             sql = "INSERT INTO entrada_saida(data_entrada_valor,recebimento,descricao,categoria,nome_receita,receita_despesa,saldo_lucro)"
            +"VALUES(?,?,?,?,?,?,? -recebimento);";
             statement = connection.prepareStatement(sql);
            
            SimpleDateFormat dataFormat = new SimpleDateFormat("yyyy-MM-dd");
            String bancoDados  = dataFormat.format(dataValor.getDate());
            
            statement.setString(1, bancoDados);
            statement.setString(2,valor.getText());
            statement.setString(3,descricao.getText());
            statement.setString(4,categoria.getSelectedItem().toString());
            statement.setString(5,nome.getText());
            statement.setString(6,situacao);
            statement.setString(7, valores2);
           
            statement.execute();
            connection.close();
            statement.close();
            rs.close();
            
            

            JOptionPane.showMessageDialog(null,"Adicionado!!");
            atualizarTelaFinanceiro();
            atualizaReceita();
            atualizaDespesa();
            atualizaTotal();

        } catch (SQLException ex) {
            Logger.getLogger(ViewControleFinanceiro.class.getName()).log(Level.SEVERE, null, ex);
        }
           
          
       
        }
        
        
        
       
    }//GEN-LAST:event_buttonAdicionarMouseClicked

    private void rdButtonEntradaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rdButtonEntradaMouseClicked
            
     // TODO add your handling code here:
    }//GEN-LAST:event_rdButtonEntradaMouseClicked

    private void rdButtonEntradaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rdButtonEntradaItemStateChanged
       situacao = "Receita";

       
    }//GEN-LAST:event_rdButtonEntradaItemStateChanged

    private void rdButtonSaidaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rdButtonSaidaItemStateChanged
        situacao = "Despesa";
    }//GEN-LAST:event_rdButtonSaidaItemStateChanged

    private void buttonAlterarControleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonAlterarControleMouseClicked
                 try {
            Connection connection = ProjetoClinica.conexaoBanco();
            String sql = "UPDATE entrada_saida SET data_entrada_valor = ?,recebimento = ?,descricao = ?,categoria = ?,nome_receita = ?,receita_despesa = ? WHERE id_entrada_saida = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
        
            SimpleDateFormat dataFormat2 = new SimpleDateFormat("yyyy-MM-dd");
            String bancoDados  = dataFormat2.format(dataValor.getDate());
        
            statement.setString(1, bancoDados);
            statement.setString(2,valor.getText());
            statement.setString(3,descricao.getText());
            statement.setString(4,categoria.getSelectedItem().toString());
            statement.setString(5,nome.getText());
            statement.setString(6,situacao);
            statement.setString(7,codigo.getText());
            
            statement.executeUpdate();

            statement.close();
            connection.close();
            JOptionPane.showMessageDialog(null,"Alterado!!");
            atualizarTelaFinanceiro();
            atualizaReceita();
            atualizaDespesa();
            atualizaTotal();
            
            
            
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(ViewControleEstoque.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }        // TODO add your handling code here:
    }//GEN-LAST:event_buttonAlterarControleMouseClicked

    private void tabelaControleFinanceiroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelaControleFinanceiroMouseClicked
                   codigo.setText(tabelaControleFinanceiro.getValueAt(tabelaControleFinanceiro.getSelectedRow(),0).toString());
                   nome.setText(tabelaControleFinanceiro.getValueAt(tabelaControleFinanceiro.getSelectedRow(),1).toString());
                   valor.setText(tabelaControleFinanceiro.getValueAt(tabelaControleFinanceiro.getSelectedRow(),2).toString());
                   categoria.setSelectedItem(tabelaControleFinanceiro.getValueAt(tabelaControleFinanceiro.getSelectedRow(),3).toString());
                  // data(tabelaControleFinanceiro.getValueAt(tabelaControleFinanceiro.getSelectedRow(),0).toString());
                   descricao.setText(tabelaControleFinanceiro.getValueAt(tabelaControleFinanceiro.getSelectedRow(),5).toString());
                   situacao = tabelaControleFinanceiro.getValueAt(tabelaControleFinanceiro.getSelectedRow(),6).toString();
                   
                   if(situacao.equals("Receita")){
                   rdButtonEntrada.setSelected(true);
                   }
                   if(situacao.equals("Despesa")){
                   rdButtonSaida.setSelected(true);
                   }
    }//GEN-LAST:event_tabelaControleFinanceiroMouseClicked

    private void buttonExcluirControleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonExcluirControleMouseClicked
                 try {
            Connection connection = ProjetoClinica.conexaoBanco();   
            String sql = "DELETE FROM entrada_saida WHERE id_entrada_saida = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1,codigo.getText());
        statement.execute();

        statement.close();
        connection.close();
        JOptionPane.showMessageDialog(null,"Produto excluído!!");
        atualizarTelaFinanceiro();
        atualizaReceita();
        atualizaDespesa();
        atualizaTotal();
        



// TODO add your handling code here:
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(ViewControleEstoque.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_buttonExcluirControleMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup GroupEntradaSaida;
    private javax.swing.JButton buttonAdicionar;
    private javax.swing.JButton buttonAlterarControle;
    private javax.swing.JButton buttonExcluirControle;
    private javax.swing.JComboBox<String> categoria;
    private javax.swing.JTextField codigo;
    private com.toedter.calendar.JDateChooser dataValor;
    private javax.swing.JTextArea descricao;
    private javax.swing.JComboBox<String> jComboBox1;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel lbEntrada;
    private javax.swing.JLabel lbSaida;
    private javax.swing.JPanel lbTotal;
    private javax.swing.JTextField nome;
    private javax.swing.JRadioButton rdButtonEntrada;
    private javax.swing.JRadioButton rdButtonSaida;
    private javax.swing.JLabel saldo_atual;
    private javax.swing.JTable tabelaControleFinanceiro;
    private javax.swing.JTextField valor;
    // End of variables declaration//GEN-END:variables
}
