/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calendario;

/**
 *
 * @author Hugo53690506
 */
public class Calendario {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
