/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividadesjava;

/**
 *
 * @author Hugo53690506
 */
public class AtividadesJava {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
