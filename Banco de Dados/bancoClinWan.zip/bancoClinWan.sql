CREATE DATABASE  IF NOT EXISTS `clinica_wanaria2` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `clinica_wanaria2`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: clinica_wanaria2
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `id_cliente` int NOT NULL AUTO_INCREMENT,
  `situacao` char(1) NOT NULL DEFAULT 'A',
  `id_pessoa` int NOT NULL,
  PRIMARY KEY (`id_cliente`),
  KEY `id_pessoa` (`id_pessoa`),
  CONSTRAINT `cliente_ibfk_1` FOREIGN KEY (`id_pessoa`) REFERENCES `pessoa` (`id_pessoa`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,'A',1),(2,'A',8),(3,'A',9),(4,'A',10),(5,'A',11),(6,'A',12),(7,'A',13),(8,'A',14),(9,'A',15),(10,'A',16),(11,'A',17);
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ficha_anamnese`
--

DROP TABLE IF EXISTS `ficha_anamnese`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ficha_anamnese` (
  `id_ficha_anamnese` int NOT NULL AUTO_INCREMENT,
  `data_registro` datetime DEFAULT CURRENT_TIMESTAMP,
  `id_cliente` int NOT NULL,
  `id_historico` int DEFAULT NULL,
  `id_termo_compromisso` int DEFAULT NULL,
  `id_observacoes` int DEFAULT NULL,
  PRIMARY KEY (`id_ficha_anamnese`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_historico` (`id_historico`),
  KEY `id_termo_compromisso` (`id_termo_compromisso`),
  KEY `id_observacoes` (`id_observacoes`),
  CONSTRAINT `ficha_anamnese_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`),
  CONSTRAINT `ficha_anamnese_ibfk_2` FOREIGN KEY (`id_historico`) REFERENCES `historico` (`id_historico`),
  CONSTRAINT `ficha_anamnese_ibfk_3` FOREIGN KEY (`id_termo_compromisso`) REFERENCES `termo_compromisso` (`id_termo_compromisso`),
  CONSTRAINT `ficha_anamnese_ibfk_4` FOREIGN KEY (`id_observacoes`) REFERENCES `observacoes` (`id_observacoes`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ficha_anamnese`
--

LOCK TABLES `ficha_anamnese` WRITE;
/*!40000 ALTER TABLE `ficha_anamnese` DISABLE KEYS */;
INSERT INTO `ficha_anamnese` VALUES (1,'2025-07-29 15:45:27',1,1,1,1),(3,'2025-07-29 15:45:49',1,2,2,2),(4,'2025-07-29 15:46:01',1,3,3,3),(7,'2025-07-29 15:46:50',1,4,NULL,4),(8,'2025-07-29 15:46:56',1,5,NULL,5),(9,'2025-07-29 15:47:03',1,6,NULL,6),(10,'2025-07-29 15:47:10',1,7,NULL,7),(12,'2025-07-29 15:47:28',1,NULL,NULL,8),(13,'2025-07-29 15:47:33',1,NULL,NULL,9),(15,'2025-07-30 15:19:29',10,16,11,18),(16,'2025-08-01 14:22:46',11,17,12,19);
/*!40000 ALTER TABLE `ficha_anamnese` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `ficha_anamnese_vw`
--

DROP TABLE IF EXISTS `ficha_anamnese_vw`;
/*!50001 DROP VIEW IF EXISTS `ficha_anamnese_vw`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `ficha_anamnese_vw` AS SELECT 
 1 AS `id_pessoa`,
 1 AS `nome`,
 1 AS `idade`,
 1 AS `data_nascimento`,
 1 AS `telefONe`,
 1 AS `cidade`,
 1 AS `genero`,
 1 AS `tratamento_estetica`,
 1 AS `obs_estetica`,
 1 AS `alergico`,
 1 AS `obs_alergico`,
 1 AS `tratamento_medico`,
 1 AS `obs_tratamento_medico`,
 1 AS `usa_medicamentos`,
 1 AS `obs_usa_medicamentos`,
 1 AS `disturbios_hormONais`,
 1 AS `obs_disturbios_hormONias`,
 1 AS `doencas_autoimune`,
 1 AS `obs_doencas_autoimine`,
 1 AS `cirurguias`,
 1 AS `obs_cirurgias`,
 1 AS `atividades_fisicas`,
 1 AS `obs_atividades_fisicas`,
 1 AS `proteses_metalicas`,
 1 AS `obs_local`,
 1 AS `agua_frequencia`,
 1 AS `obs_quantos_litros`,
 1 AS `usa_protetor_solar`,
 1 AS `obs_fator`,
 1 AS `doces`,
 1 AS `carboidratos`,
 1 AS `frituras`,
 1 AS `proteina`,
 1 AS `verduras_legumes`,
 1 AS `frutas`,
 1 AS `fuma`,
 1 AS `adquiriu_herpes`,
 1 AS `queloides`,
 1 AS `gestante_amamentando`,
 1 AS `protese_dentaria`,
 1 AS `portador_marcapasso`,
 1 AS `hipertesao`,
 1 AS `diabetes`,
 1 AS `epilepsia`,
 1 AS `depressao`,
 1 AS `crise_ansiedade`,
 1 AS `tomar_sol`,
 1 AS `ultima_menstruacao`,
 1 AS `usa_produtos`,
 1 AS `queixas_esteticas`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `historico`
--

DROP TABLE IF EXISTS `historico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `historico` (
  `id_historico` int NOT NULL AUTO_INCREMENT,
  `tratamento_estetica` char(1) NOT NULL,
  `obs_estetica` varchar(100) DEFAULT NULL,
  `alergico` char(1) NOT NULL,
  `obs_alergico` varchar(100) DEFAULT NULL,
  `tratamento_medico` char(1) NOT NULL,
  `obs_tratamento_medico` varchar(100) DEFAULT NULL,
  `usa_medicamentos` char(1) NOT NULL,
  `obs_usa_medicamentos` varchar(100) DEFAULT NULL,
  `disturbios_hormonais` char(1) NOT NULL,
  `obs_disturbios_hormonias` varchar(100) DEFAULT NULL,
  `doencas_autoimune` char(1) NOT NULL,
  `obs_doencas_autoimine` varchar(100) DEFAULT NULL,
  `cirurguias` char(1) NOT NULL,
  `obs_cirurgias` varchar(100) DEFAULT NULL,
  `atividades_fisicas` char(1) NOT NULL,
  `obs_atividades_fisicas` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_historico`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historico`
--

LOCK TABLES `historico` WRITE;
/*!40000 ALTER TABLE `historico` DISABLE KEYS */;
INSERT INTO `historico` VALUES (1,'?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?'),(2,'N','','N','','N','','N','','N','','N','','S','Amígdala','S','Academia'),(3,'S','Limpeza de Pele','N','sdasdasdassd','N','asdasdasdad','N','sadasdasdas','N','sdasdasdas','N','sdasdasdas','N','sdasdasdas','N','sdasdasdas'),(4,'N','','N','','N','','N','','N','','N','','S','Amígdala','S','Academia'),(5,'S','sadasdasd','S','sadasdasd','S','sadasdasd','S','sadasdasd','S','sadasdasd','S','sadasdasd','S','sadasdasd','S','sadasdasd'),(6,'S','sdadasdas','S','sdadasdas','S','sdadasdas','S','sdadasdas','S','sdadasdas','S','sdadasdas','S','sdadasdas','S','sdadasdas'),(7,'N','','N','','N','','N','','N','','N','','N','','N',''),(8,'N','','N','','N','','N','','N','','N','','N','','N',''),(9,'N','','N','','N','','N','','N','','N','','N','','N',''),(10,'N','','N','','N','','N','','N','','N','','N','','N',''),(11,'N','','N','','N','','N','','N','','N','','S','No dedo','S','Academia'),(12,'N','','N','','N','','N','','N','','N','','S','No dedo','S','Academia'),(13,'N','','N','','N','','N','','N','','N','','S','No dedo','S','Academia'),(14,'N','','N','','N','','N','','N','','N','','S','No dedo','S','Academia'),(15,'N','','N','','N','','N','','N','','N','','S','No dedo','S','Academia'),(16,'N','','N','','N','','N','','N','','N','','N','','N',''),(17,'S','Limpeza de pele','N','','N','','N','','N','','N','','N','','S','Academia');
/*!40000 ALTER TABLE `historico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login` (
  `id_pessoa` int NOT NULL AUTO_INCREMENT,
  `usuario` varchar(30) NOT NULL,
  `senha` varchar(40) NOT NULL,
  `situacao` char(1) DEFAULT 'A',
  PRIMARY KEY (`id_pessoa`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES (1,'admin','490640B43519C77281CB2F8471E61A71','A');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `observacoes`
--

DROP TABLE IF EXISTS `observacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `observacoes` (
  `id_observacoes` int NOT NULL AUTO_INCREMENT,
  `proteses_metalicas` char(1) NOT NULL,
  `obs_local` varchar(100) DEFAULT NULL,
  `agua_frequencia` char(1) NOT NULL,
  `obs_quantos_litros` varchar(100) DEFAULT NULL,
  `usa_protetor_solar` char(1) NOT NULL,
  `obs_fator` varchar(100) DEFAULT NULL,
  `doces` varchar(20) NOT NULL,
  `carboidratos` varchar(20) NOT NULL,
  `frituras` varchar(20) NOT NULL,
  `proteina` varchar(20) NOT NULL,
  `verduras_legumes` varchar(20) NOT NULL,
  `frutas` varchar(20) NOT NULL,
  `fuma` char(1) NOT NULL,
  `adquiriu_herpes` char(1) NOT NULL,
  `queloides` char(1) NOT NULL,
  `gestante_amamentando` char(1) NOT NULL,
  `protese_dentaria` char(1) NOT NULL,
  `portador_marcapasso` char(1) NOT NULL,
  PRIMARY KEY (`id_observacoes`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `observacoes`
--

LOCK TABLES `observacoes` WRITE;
/*!40000 ALTER TABLE `observacoes` DISABLE KEYS */;
INSERT INTO `observacoes` VALUES (1,'N','','S','2,5 litros','N','','Moderado','Moderado','Pouco','Moderado','Moderado','Moderado','N','N','N','N','N','N'),(2,'N','sdasdasdas','S','sdasdasdas','S','sdasdasdas','Moderado','Moderado','Moderado','Moderado','Moderado','Moderado','N','N','N','N','N','N'),(3,'N','N','N','N','N','N','2025-07-17','sdasdasdas','sdasdasdas','Moderado','Moderado','Moderado','N','N','N','N','N','N'),(4,'N','','S','2,5 litros','N','','Moderado','Moderado','Moderado','Moderado','Moderado','Moderado','N','N','N','N','N','N'),(5,'N','N','N','N','N','N','2025-07-06','','','Moderado','Moderado','Moderado','N','N','N','N','N','N'),(6,'S','sadasdasd','S','sadasdasd','S','sadasdasd','Moderado','Moderado','Moderado','Moderado','Moderado','Moderado','N','N','N','N','N','N'),(7,'N','N','N','N','N','N','2025-07-17','sadasdasd','sadasdasd','Moderado','Moderado','Moderado','N','N','N','N','N','N'),(8,'S','sdadasdas','S','sdadasdas','S','sdadasdas','Moderado','Moderado','Moderado','Moderado','Moderado','Moderado','N','N','N','N','N','N'),(9,'N','','S','2,5 litros','N','','Moderado','Moderado','Pouco','Moderado','Moderado','Moderado','N','N','N','N','N','N'),(10,'N','','N','','N','','Moderado','Moderado','Moderado','Moderado','Moderado','Moderado','N','N','N','N','N','N'),(11,'N','','S','3.0 litros','N','','Muito','Moderado','Moderado','Moderado','Moderado','Moderado','N','N','N','N','N','N'),(12,'N','','S','3.0 litros','N','','Muito','Moderado','Moderado','Moderado','Moderado','Moderado','N','N','N','N','N','N'),(13,'N','','S','2.0 litros','N','','Moderado','Moderado','Moderado','Moderado','Moderado','Pouco','N','N','N','N','S','N'),(14,'N','','S','2.0 litros','N','','Moderado','Moderado','Moderado','Moderado','Moderado','Pouco','N','N','N','N','S','N'),(15,'N','','S','2.0 litros','N','','Moderado','Moderado','Moderado','Moderado','Moderado','Pouco','N','N','N','N','S','N'),(16,'N','','S','2.0 litros','N','','Moderado','Moderado','Moderado','Moderado','Moderado','Pouco','N','N','N','N','S','N'),(17,'N','','S','2.0 litros','N','','Moderado','Moderado','Moderado','Moderado','Moderado','Pouco','N','N','N','N','S','N'),(18,'N','','N','','N','','Moderado','Moderado','Moderado','Moderado','Moderado','Moderado','N','N','N','N','N','N'),(19,'N','','S','3 litros','S','40','Moderado','Muito','Pouco','Muito','Muito','Moderado','N','N','N','N','N','N');
/*!40000 ALTER TABLE `observacoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pessoa`
--

DROP TABLE IF EXISTS `pessoa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pessoa` (
  `id_pessoa` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  `idade` varchar(50) DEFAULT NULL,
  `data_nascimento` date NOT NULL,
  `telefone` varchar(35) DEFAULT NULL,
  `cidade` varchar(50) DEFAULT NULL,
  `genero` varchar(35) DEFAULT NULL,
  `situacao` char(1) NOT NULL DEFAULT 'A',
  PRIMARY KEY (`id_pessoa`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pessoa`
--

LOCK TABLES `pessoa` WRITE;
/*!40000 ALTER TABLE `pessoa` DISABLE KEYS */;
INSERT INTO `pessoa` VALUES (1,'Hugo Ruan Miranda','17','2025-07-12','61998909331','Samambaia',NULL,'A'),(2,'2 Hugo Ruan ','17','2007-09-16','(61)990038921','Gama',NULL,'A'),(3,'Hugo','23','2025-07-04','342342342','Plano Piloto',NULL,'A'),(4,'Hugo Ruan','17','2007-09-16','61998809023','Samambaia',NULL,'A'),(5,'dfsdfsdfsdf','21','2025-07-04','3423423423','Paranoá',NULL,'A'),(6,'dasdasdaaswsda','21','2025-07-04','324234234234','Plano Piloto',NULL,'A'),(7,'Iraildo Sousa','25','1999-09-26','(61)991996655','Taguatinga','Masculino','A'),(8,'fsdfssfsd','32','2025-07-04','32423423423','Gama','Masculino','A'),(9,'Miguel Sanots','12','2013-09-17','312312312123','Planaltina','Masculino','A'),(10,'Miguel Sanots','12','2013-09-17','312312312123','Planaltina','Masculino','A'),(11,'Jandson Santos','35','1990-01-08','61989908771','Samambaia','Masculino','A'),(12,'Jandson Santos','35','1990-01-08','61989908771','Samambaia','Masculino','A'),(13,'Jandson Santos','35','1990-01-08','61989908771','Samambaia','Masculino','A'),(14,'Jandson Santos','35','1990-01-08','61989908771','Samambaia','Masculino','A'),(15,'Jandson Santos','35','1990-01-08','61989908771','Samambaia','Masculino','A'),(16,'DSADASD','23','2025-07-10','342342342234','Plano Piloto','Masculino','A'),(17,'Joao Maria','20','2025-09-27','(61)990034567','Paranoá','Masculino','A');
/*!40000 ALTER TABLE `pessoa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `termo_compromisso`
--

DROP TABLE IF EXISTS `termo_compromisso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `termo_compromisso` (
  `id_termo_compromisso` int NOT NULL AUTO_INCREMENT,
  `hipertesao` char(1) NOT NULL,
  `diabetes` char(1) NOT NULL,
  `epilepsia` char(1) NOT NULL,
  `depressao` char(1) NOT NULL,
  `crise_ansiedade` char(1) NOT NULL,
  `tomar_sol` char(1) NOT NULL,
  `ultima_menstruacao` date DEFAULT NULL,
  `usa_produtos` varchar(100) DEFAULT NULL,
  `queixas_esteticas` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_termo_compromisso`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `termo_compromisso`
--

LOCK TABLES `termo_compromisso` WRITE;
/*!40000 ALTER TABLE `termo_compromisso` DISABLE KEYS */;
INSERT INTO `termo_compromisso` VALUES (1,'N','N','N','N','N','N','2025-01-01','N','N'),(2,'N','N','N','N','N','N','2025-07-04','sdadasdas','sdadasdas'),(3,'N','N','N','N','N','N','2025-07-09','sdasdas','asdasdas'),(4,'N','N','N','N','N','N','2025-07-09','dsadasdas','asdasdas'),(5,'N','N','N','N','N','N','2025-07-17','dasfsdfsd','sdfsdfsd'),(6,'N','N','N','N','N','N','2025-07-06','',''),(7,'N','N','N','N','N','N','2025-07-06','',''),(8,'N','N','N','N','N','N','2025-07-06','',''),(9,'N','N','N','N','N','N','2025-07-06','',''),(10,'N','N','N','N','N','N','2025-07-06','sdfsdf','dsffsdf'),(11,'N','N','N','N','N','N','2025-07-30','SDFSDFSDF','SDFSDFSDFSD'),(12,'N','N','N','N','N','S','2025-08-03','Protetor solar','');
/*!40000 ALTER TABLE `termo_compromisso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'clinica_wanaria2'
--

--
-- Dumping routines for database 'clinica_wanaria2'
--

--
-- Final view structure for view `ficha_anamnese_vw`
--

/*!50001 DROP VIEW IF EXISTS `ficha_anamnese_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ficha_anamnese_vw` AS select `p`.`id_pessoa` AS `id_pessoa`,`p`.`nome` AS `nome`,`p`.`idade` AS `idade`,`p`.`data_nascimento` AS `data_nascimento`,`p`.`telefone` AS `telefONe`,`p`.`cidade` AS `cidade`,`p`.`genero` AS `genero`,`h`.`tratamento_estetica` AS `tratamento_estetica`,`h`.`obs_estetica` AS `obs_estetica`,`h`.`alergico` AS `alergico`,`h`.`obs_alergico` AS `obs_alergico`,`h`.`tratamento_medico` AS `tratamento_medico`,`h`.`obs_tratamento_medico` AS `obs_tratamento_medico`,`h`.`usa_medicamentos` AS `usa_medicamentos`,`h`.`obs_usa_medicamentos` AS `obs_usa_medicamentos`,`h`.`disturbios_hormonais` AS `disturbios_hormONais`,`h`.`obs_disturbios_hormonias` AS `obs_disturbios_hormONias`,`h`.`doencas_autoimune` AS `doencas_autoimune`,`h`.`obs_doencas_autoimine` AS `obs_doencas_autoimine`,`h`.`cirurguias` AS `cirurguias`,`h`.`obs_cirurgias` AS `obs_cirurgias`,`h`.`atividades_fisicas` AS `atividades_fisicas`,`h`.`obs_atividades_fisicas` AS `obs_atividades_fisicas`,`obs`.`proteses_metalicas` AS `proteses_metalicas`,`obs`.`obs_local` AS `obs_local`,`obs`.`agua_frequencia` AS `agua_frequencia`,`obs`.`obs_quantos_litros` AS `obs_quantos_litros`,`obs`.`usa_protetor_solar` AS `usa_protetor_solar`,`obs`.`obs_fator` AS `obs_fator`,`obs`.`doces` AS `doces`,`obs`.`carboidratos` AS `carboidratos`,`obs`.`frituras` AS `frituras`,`obs`.`proteina` AS `proteina`,`obs`.`verduras_legumes` AS `verduras_legumes`,`obs`.`frutas` AS `frutas`,`obs`.`fuma` AS `fuma`,`obs`.`adquiriu_herpes` AS `adquiriu_herpes`,`obs`.`queloides` AS `queloides`,`obs`.`gestante_amamentando` AS `gestante_amamentando`,`obs`.`protese_dentaria` AS `protese_dentaria`,`obs`.`portador_marcapasso` AS `portador_marcapasso`,`tc`.`hipertesao` AS `hipertesao`,`tc`.`diabetes` AS `diabetes`,`tc`.`epilepsia` AS `epilepsia`,`tc`.`depressao` AS `depressao`,`tc`.`crise_ansiedade` AS `crise_ansiedade`,`tc`.`tomar_sol` AS `tomar_sol`,`tc`.`ultima_menstruacao` AS `ultima_menstruacao`,`tc`.`usa_produtos` AS `usa_produtos`,`tc`.`queixas_esteticas` AS `queixas_esteticas` from (((((`ficha_anamnese` `fa` left join `historico` `h` on((`fa`.`id_historico` = `h`.`id_historico`))) left join `termo_compromisso` `tc` on((`fa`.`id_termo_compromisso` = `tc`.`id_termo_compromisso`))) left join `observacoes` `obs` on((`fa`.`id_observacoes` = `obs`.`id_observacoes`))) join `cliente` `c` on((`c`.`id_cliente` = `fa`.`id_cliente`))) join `pessoa` `p` on((`c`.`id_pessoa` = `p`.`id_pessoa`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-01 17:42:23
